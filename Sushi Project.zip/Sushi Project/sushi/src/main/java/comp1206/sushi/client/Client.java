package comp1206.sushi.client;

import java.util.*;

import comp1206.sushi.common.*;
import comp1206.sushi.common.Comms;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javax.swing.*;

public class Client implements ClientInterface {

    private static final Logger logger = LogManager.getLogger("Client");

	public Restaurant restaurant;
	public ArrayList<Postcode> postcodes = new ArrayList<Postcode>();
	public ArrayList<Dish> dishes = new ArrayList<Dish>();
	public ArrayList<Order> orders = new ArrayList<Order>();
	public ArrayList<User> users = new ArrayList<User>();
	private ArrayList<UpdateListener> listeners = new ArrayList<UpdateListener>();
	private User currentUser;
	private int orderNum = 0;
	private Map<User,ArrayList<Order>> userToOrder = new HashMap<>();
	private Map<User,Map<Dish,Number>> userToBasket = new HashMap<>();
	private Comms comms;
	private ClientComms clientComms;
	private DataPersistence dataPersist;
	
	public Client() {
        logger.info("Starting up client...");

		this.comms = new Comms(this);
		Thread t = new Thread(this.comms);
		t.start();

        postcodes.add(new Postcode("SO17 1TJ"));
        postcodes.add(new Postcode("SO17 1BX"));

		restaurant = new Restaurant("Sushi Restaurant", postcodes.get(0));

		users.add(new User("User 1", "password", "Uni of Southampton", postcodes.get(1)));

		dataPersist = new DataPersistence();
	}

	public List<User> getUsers(){return users;}
	
	@Override
	public Restaurant getRestaurant() {
		return restaurant;
	}
	
	@Override
	public String getRestaurantName() {
		return restaurant.getName();
	}

	@Override
	public Postcode getRestaurantPostcode() {
		return restaurant.getLocation();
	}
	
	@Override
	public User register(String username, String password, String address, Postcode postcode) {
		User newUser = null;
		boolean existingUser = false;

		for (User user:users){
			if(user.getName().equals(username)){
				existingUser = true;
				JOptionPane.showMessageDialog(null, "This user already exists.", "Error", JOptionPane.ERROR_MESSAGE);
			}
		}

		if (existingUser==false){
			newUser = new User(username, password, address, postcode);
			users.add(newUser);
			ArrayList<Order> myOrders = new ArrayList<>();
			Map<Dish,Number> myBask = new HashMap<>();
			userToOrder.put(newUser,myOrders);
			userToBasket.put(newUser,myBask);
			currentUser=newUser;
		}

		sendMessage();

		return newUser;
	}

	@Override
	public User login(String username, String password) {
		for (User user:users){
			if (user.getName().equals(username) && user.getPassword().equals(password)){
				currentUser = user;
				return user;
			}
		}

		return null;
	}

	@Override
	public List<Postcode> getPostcodes() {
		return postcodes;
	}

	@Override
	public List<Dish> getDishes() {
		return dishes;
	}

	@Override
	public String getDishDescription(Dish dish) {
		return dish.getDescription();
	}

	@Override
	public Number getDishPrice(Dish dish) {
		return dish.getPrice();
	}

	@Override
	public Map<Dish, Number> getBasket(User user) {
		return userToBasket.get(user);
	}

	@Override
	public Number getBasketCost(User user) {
		Map<Dish,Number> basket = new HashMap<>();
		float cost = 0;

		basket = userToBasket.get(user);

		for (Map.Entry<Dish,Number> entry : basket.entrySet()) {
			cost = cost + (entry.getKey().getPrice().floatValue() * entry.getValue().intValue());
		}

		return cost;
	}

	@Override
	public void addDishToBasket(User user, Dish dish, Number quantity) {
	    /*if (user.getBasket().get(dish)==null){
			this.userToBasket.get(user).put(dish,quantity);
        }
        else {
            int amount = quantity.intValue() + user.getBasket().get(dish).intValue();
			this.userToBasket.get(user).put(dish,amount);
        }*/

		userToBasket.get(user).put(dish,quantity);
	}

	@Override
	public void updateDishInBasket(User user, Dish dish, Number quantity) {
		userToBasket.get(user).put(dish,quantity);
		/*if(quantity == Integer.valueOf(0)) {
			user.getBasket().remove(dish);
			this.notifyUpdate();
		} else {
			this.userToBasket.get(user).put(dish,quantity);
		}*/

	}

	@Override
	public Order checkoutBasket(User user) {
		Order order = new Order(user, userToBasket.get(user));
		order.setOrderID(user.getName()+orderNum++);
		order.setOrderUser(user);
		orders.add(order);
		userToOrder.get(user).add(order);
		clearBasket(user);
		sendMessage();
		return order;
	}

	@Override
	public void clearBasket(User user) {
		user.getBasket().clear();
		this.notifyUpdate();
	}

	@Override
	public List<Order> getOrders(User user) {
		return userToOrder.get(user);
	}

	@Override
	public boolean isOrderComplete(Order order) {
		return false;
	}

	@Override
	public String getOrderStatus(Order order) {
		return order.getStatus();
	}

	@Override
	public Number getOrderCost(Order order) {
		return order.getCost();
	}

	@Override
	public void cancelOrder(Order order) {
		if(order.getStatus().equals("Pending")) {
			orders.remove(order);
		}
		else{

		}
	}

	@Override
	public void addUpdateListener(UpdateListener listener) {
		this.listeners.add(listener);

	}

	@Override
	public void notifyUpdate() {
		this.listeners.forEach(listener -> listener.updated(new UpdateEvent()));

	}

	public User getCurrentUser(){
		return currentUser;
	}


	public void sendMessage(){
		clientComms.sendMessage();
	}

	public void setClientComms(ClientComms clientComms){
		this.clientComms = clientComms;
	}

	public void inputInfo(Message input){
		dishes = (ArrayList) input.getDishes();
		users = (ArrayList) input.getUsers();
		postcodes = (ArrayList) input.getPostcodes();
	}


}
