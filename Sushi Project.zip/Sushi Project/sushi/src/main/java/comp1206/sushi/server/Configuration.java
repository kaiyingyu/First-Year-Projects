package comp1206.sushi.server;

import comp1206.sushi.common.*;
import comp1206.sushi.server.Server;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Configuration {

    Server server;
    ArrayList<Postcode> postcodes = new ArrayList<>();
    Restaurant restaurant;
    ArrayList<Supplier> suppliers = new ArrayList<>();
    ArrayList<Ingredient> ingredients = new ArrayList<>();
    ArrayList<Dish> dishes = new ArrayList<>();
    ArrayList<User> users = new ArrayList<>();
    ArrayList<Staff> staff = new ArrayList<>();
    ArrayList<Drone> drones = new ArrayList<>();
    ArrayList<Order> orders = new ArrayList<>();
    //private StockManagement stockManager = new StockManagement(server);

    public Configuration(String file,Server server){
        this.server = server;
        BufferedReader reader;
        String line;

        try {
            reader = new BufferedReader(new FileReader(file));

            while ((line = reader.readLine()) != null) {
                getInfo(line);
            }
        } catch (IOException error){
            error.printStackTrace();
        }
    }

    public void getInfo(String line){
        if(line.length() > 0) {
            String[] parts = line.split(":");
            Postcode code;
            Supplier supplier;
            Drone drone;

            switch (parts[0]){
                case "POSTCODE":
                    server.addPostcode(parts[1]);
                    break;
                case "RESTAURANT":
                    server.restaurant = new Restaurant(parts[1], getMatchingPostcode(parts[2]));
                    break;
                case "SUPPLIER":
                    server.addSupplier(parts[1], getMatchingPostcode(parts[2]));
                    break;
                case "INGREDIENT":
                    server.addIngredient(parts[1],parts[2],getMatchingSupplier(parts[3]), Integer.valueOf(parts[4]), Integer.valueOf(parts[5]), Integer.valueOf(parts[6]));
                    break;
                case "DISH":
                    server.addDish(parts[1],parts[2],Integer.valueOf(parts[3]), Integer.valueOf(parts[4]), Integer.valueOf(parts[5]));

                    for(Dish temp:server.getDishes()) {
                        if (temp.getName().equals(parts[1])) {
                            Map<Ingredient,Number> dishRecipe = new HashMap<>();
                            ArrayList<String> recipes = new ArrayList<>();
                            String[] recipeParts = parts[6].split(",");

                            for (String part : recipeParts) {
                                recipes.add(part);
                            }

                            for (String recipe : recipes) {

                                for (Ingredient recipeIngredient : server.getIngredients()) {
                                    if (recipeIngredient.getName().equals(recipe.split(" \\* ")[1])) {
                                        dishRecipe.put(recipeIngredient, Integer.valueOf(recipe.split(" \\*")[0]));
                                    }
                                }

                            }

                            server.setRecipe(temp, dishRecipe);

                        }
                    }

                    break;
                case "USER":
                    server.addUser(parts[1], parts[2], parts[3], getMatchingPostcode(parts[4]));
                    break;
                case "ORDER":
                    ArrayList<String> myOrders = new ArrayList<>();
                    String[] orderParts = parts[2].split(",");
                    Map<Dish,Number> myOrder = new HashMap<>();
                    Order orderToAdd;

                    for (String temp:orderParts){
                        myOrders.add(temp);
                    }

                    for(String order:myOrders) {
                        for (Dish orderDish : dishes) {
                            if(orderDish.getName().equals(order.split(" \\* ")[1])){
                                myOrder.put(orderDish,Integer.valueOf(order.split(" \\* ")[0]));
                            }
                        }
                    }

                    User orderUser = getMatchingUser(parts[1]);
                    orderUser.setPostcode(getMatchingPostcode(orderUser.getPostcode().getName()));
                    server.addOrder(orderUser, myOrder);

                    break;
                case "STAFF":
                    server.addStaff(parts[1]);
                    break;
                case "DRONE":
                    server.addDrone(Integer.valueOf(parts[1]));
                    break;
            }
        }

    }

    public Postcode getMatchingPostcode(String postcode){
        for (Postcode code:server.getPostcodes()){
            if(code.getName().equals(postcode)){
                return code;
            }
        }

        return null;
    }

    public Supplier getMatchingSupplier(String supplier){
        for(Supplier supply:server.getSuppliers()){
            if(supply.getName().equals(supplier)){
                return supply;
            }
        }

        return null;
    }

    public User getMatchingUser(String user){
        for(User temp:server.getUsers()){
            if(temp.getName().equals(user)){
                return temp;
            }
        }

        return null;
    }

    //public StockManagement getStockManager(){return stockManager;}

    public ArrayList getPostcodes(){
        return postcodes;
    }

    public Restaurant getRestaurants(){
        return restaurant;
    }

    public ArrayList getSuppliers(){
        return suppliers;
    }

    public ArrayList getIngredients(){
        return ingredients;
    }

    public ArrayList getDishes(){
        return dishes;
    }

    public ArrayList getUsers(){
        return users;
    }

    public ArrayList getOrders(){
        return orders;
    }

    public ArrayList getStaffMembers(){
        return staff;
    }

    public ArrayList getDrones(){
        return drones;
    }
}
