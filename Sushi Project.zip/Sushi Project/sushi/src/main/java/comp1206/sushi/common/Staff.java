package comp1206.sushi.common;

import comp1206.sushi.server.StockManagement;

import java.util.HashMap;
import java.util.Map;

public class Staff extends Model implements Runnable{

	private String name;
	private String status;
	private Number fatigue;
	private StockManagement stockManager;
	private boolean exit;

	public Staff(String name, StockManagement stockManager) {
		this.setName(name);
		this.setFatigue(0);
		exit = false;
		this.stockManager = stockManager;
	}

	public void run(){
			while (true) {

				try {
					setStatus("Idle");
					Dish dishToRestock = null;

					Thread.sleep(10);

					synchronized (stockManager) {
						dishToRestock = stockManager.getDishToRestock();
					}

					if(dishToRestock!=null){
						makeDish(dishToRestock);
					}

				}catch (InterruptedException e){
					return;
				}
			}
	}

	public void rest() throws InterruptedException{

		System.out.println(getName() + " is too tired. They need a break.");
		setStatus("Resting");

		for (int i = 0; i < 10; i++){
			Thread.sleep(5000);

			setFatigue(fatigue.intValue()-10);
			stockManager.server.notifyUpdate();
		}
		setStatus("Idle");

	}

	public void makeDish(Dish dishToRestock) throws InterruptedException{

		setStatus("Working");
		int time = (int) (Math.random() * ((60000 - 20000) + 1)) + 20000;
		System.out.println(this.getName() + " is making " + dishToRestock.getName() + ". The dish will take " + Math.round(time / 1000) + "s");

		Thread.sleep(time);

		System.out.println(this.getName() + " is done and made " + dishToRestock.getName());
		setFatigue(fatigue.intValue() + 10);

		stockManager.updateDishStock(dishToRestock);

		setStatus("Idle");

		if(getFatigue().intValue()==100) {
			rest();
		}

	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Number getFatigue() {
		return fatigue;
	}

	public void setFatigue(Number fatigue) {
		this.fatigue = fatigue;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		notifyUpdate("status",this.status,status);
		this.status = status;
	}

	public void stopStaff(){
		this.exit = true;
	}


}
