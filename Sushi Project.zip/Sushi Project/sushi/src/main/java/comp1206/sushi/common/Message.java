package comp1206.sushi.common;

import comp1206.sushi.client.Client;
import comp1206.sushi.common.Dish;
import comp1206.sushi.common.Postcode;
import comp1206.sushi.common.Restaurant;
import comp1206.sushi.common.User;
import comp1206.sushi.server.Server;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Message implements Serializable {
    String message;

    private Server server;
    private Client client;

    private Restaurant restaurant;
    private List<Postcode> postcodes;
    private List<Dish> dishes;
    private List<User> users;
    private List<Order> orders;

    Message(String message){
        this.message = message;
    }

    Message(Server server){
        dishes = server.getDishes();
        users = server.getUsers();
        postcodes = server.getPostcodes();
    }

    Message(Client client){
        users = client.getUsers();
        orders = client.getOrders(client.getCurrentUser());
    }

    public String getMessage(){
        return message;
    }

    public Restaurant getRestaurant(){
        return restaurant;
    }

    public List<Postcode> getPostcodes(){
        return postcodes;
    }

    public List<Dish> getDishes(){
        return dishes;
    }

    public List<User> getUsers(){
        return users;
    }

    public List<Order> getOrders(){return orders;}
}
