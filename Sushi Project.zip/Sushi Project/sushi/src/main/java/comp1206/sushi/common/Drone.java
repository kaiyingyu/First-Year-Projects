package comp1206.sushi.common;

import comp1206.sushi.server.ServerInterface;
import comp1206.sushi.server.StockManagement;

import java.util.HashMap;
import java.util.Map;

public class Drone extends Model implements Runnable{

	private Number speed;
	private Number progress;
	
	private Number capacity;
	private Number battery;
	
	private String status;
	
	private Postcode source;
	private Postcode destination;

	private StockManagement stockManager;
	private OrderManagement orderManager;

	private boolean exit = false;
	private int seconds;

	public Drone(Number speed, StockManagement stockManager, OrderManagement orderManager) {
		this.setSpeed(speed);
		this.setCapacity(5000);
		this.setBattery(100);
		this.stockManager = stockManager;
		this.orderManager = orderManager;
		seconds = 0;
	}

	public void run(){
		Ingredient ingredientToRestock;
		Order orderToSend;
		boolean notFull = true;

			while (true) {

				try {
					setStatus("Idle");
					setSource(stockManager.server.getRestaurantPostcode());

					Thread.sleep(10);

					synchronized (stockManager) {
						ingredientToRestock = stockManager.getIngredientToRestock();
					}

					if(ingredientToRestock!=null){
						notFull = checkCapacity(ingredientToRestock);
					}

					if (ingredientToRestock != null && notFull) {
						if (restock(ingredientToRestock)) {
							System.out.println("Not restocked since drone returned");
							stockManager.stockIngredients(ingredientToRestock, -(ingredientToRestock.getRestockAmount().intValue()));
						}
					} else {
					}

					if(ingredientToRestock==null){
						synchronized (orderManager) {
							orderToSend = orderManager.getOrderToDeliver();
						}

						if(orderToSend!=null){
							if(orderManager.fillOrder(orderToSend)==true) {
								if (deliverOrder(orderToSend)) {
									System.out.println("Not delivered since " + this.getName() + " returned to charge.");
								}
							}
						}
					}


				}catch(InterruptedException e){
					return;
				}
			}

	}

	public boolean checkCapacity(Ingredient ingredient) throws InterruptedException{
		if((getCapacity().intValue()-(ingredient.getRestockAmount().intValue()*ingredient.getWeight().intValue()))<0){
			System.out.println("There is insufficient capacity to complete this task");
			return false;
		}

		return true;

	}

	public boolean restock(Ingredient ingredientToRestock) throws InterruptedException{
		boolean recharged = false;

		setDestination(ingredientToRestock.getSupplier().getPostcode());

		recharged = travel(ingredientToRestock, null);

		if(recharged){
			return recharged;
		}

		System.out.println(this.getName() + " has reached its destination");
		setCapacity(getCapacity().intValue()-(ingredientToRestock.getRestockAmount().intValue()*ingredientToRestock.getWeight().intValue()));
		setSource(ingredientToRestock.getSupplier().getPostcode());
		setDestination(stockManager.server.getRestaurantPostcode());

		recharged = travel(ingredientToRestock, null);

		if(recharged){
			return recharged;
		}

		System.out.println(this.getName() + " has returned to its source");
		setCapacity(5000);

		if(battery.intValue()==0){
			recharge();
		}

		if(ingredientToRestock!=null) {
			stockManager.updateIngredientStock(ingredientToRestock);
		}


		return false;
	}

	public boolean deliverOrder(Order orderToSend) throws InterruptedException{
		boolean recharged = false;

		orderToSend.setStatus("Being Delivered");
		setDestination(orderToSend.getOrderUser().getPostcode());
		recharged = travel(null, orderToSend);

		if(recharged){
			return recharged;
		}

		System.out.println(this.getName() + " has reached its destination");
		setSource(orderToSend.getOrderUser().getPostcode());
		setDestination(stockManager.server.getRestaurantPostcode());

		recharged = travel(null, orderToSend);

		if(recharged){
			return recharged;
		}

		System.out.println(this.getName() + " has returned to its source");
		setCapacity(5000);

		if(battery.intValue()==0){
			recharge();
		}

		orderToSend.setStatus("Delivered");

		Thread.sleep(1000);

		orderManager.updateOrderList(orderToSend);

		return false;

	}

	public boolean travel(Ingredient ingredientToRestock, Order orderToSend) throws InterruptedException{
		int time = 5000;
		setProgress(0);

		if(battery.intValue()==0){
			recharge();
			return true;
		}

		setStatus("Working");
		setProgress(0);

		if(ingredientToRestock != null) {
			time = Math.round(stockManager.server.getSupplierDistance(ingredientToRestock.getSupplier()).intValue() / getSpeed().intValue());
			System.out.println(this.getName() + " will take " + time + "s to travel " + stockManager.server.getSupplierDistance(ingredientToRestock.getSupplier()) + " to restock " + ingredientToRestock.getName());
		}

		else if (orderToSend != null){
			time = Math.round(orderToSend.getDistance().intValue() / getSpeed().intValue());
			System.out.println(this.getName() + " will take " + time + "s to travel " + orderToSend.getDistance() + " to deliver " + orderToSend.getName());
		}

		time = time*1000;

		for (int i = 0; i < time - 1000; i = i + 1000) {
			if(battery.intValue()==0){
				recharge();
				return true;
			}

			setProgress(Math.round(progress.doubleValue() + (double) 100000 / time));

			Thread.sleep(1000);
			seconds++;

			if(seconds==60){
				setBattery(battery.intValue()-1);
				seconds=0;
			}

			stockManager.server.notifyUpdate();
		}

		if(battery.intValue()==0){
			recharge();
			return true;
		}

		setProgress(100);
		Thread.sleep(1000);

		seconds++;
		if(seconds==60){
			setBattery(battery.intValue()-1);
			seconds=0;
		}

		stockManager.server.notifyUpdate();


		return false;
	}

	public void recharge(){
		System.out.println(getName() + " is out of battery and is returning to base");
		setStatus("Recharging");
		setDestination(stockManager.server.getRestaurantPostcode());

		for(int i=0; i<10; i++){
			try {
				setBattery(battery.intValue()+10);
				Thread.sleep(5000);
			} catch (InterruptedException e){
				e.printStackTrace();
			}
		}

		System.out.println(getName() + " has recharged");
		setStatus("Idle");

	}

	public Number getSpeed() {
		return speed;
	}

	
	public Number getProgress() {
		return progress;
	}
	
	public void setProgress(Number progress) {
		this.progress = progress;
	}
	
	public void setSpeed(Number speed) {
		this.speed = speed;
	}
	
	@Override
	public String getName() {
		return "Drone (" + getSpeed() + " speed)";
	}

	public Postcode getSource() {
		return source;
	}

	public void setSource(Postcode source) {
		this.source = source;
	}

	public Postcode getDestination() {
		return destination;
	}

	public void setDestination(Postcode destination) {
		this.destination = destination;
	}

	public Number getCapacity() {
		return capacity;
	}

	public void setCapacity(Number capacity) {
		this.capacity = capacity;
	}

	public Number getBattery() {
		return battery;
	}

	public void setBattery(Number battery) {
		this.battery = battery;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		notifyUpdate("status",this.status,status);
		this.status = status;
	}

	public void stop(){
		exit = true;
	}
	
}
