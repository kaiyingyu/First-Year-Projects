package comp1206.sushi.common;

import comp1206.sushi.client.Client;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;

public class ClientComms {
    private Socket socket;
    private static int port = 5888;
    private ObjectInputStream inputStream;
    private ObjectOutputStream outputStream;
    private Client client;


    public ClientComms(Client client){
        this.client = client;
        this.client.setClientComms(this);

        try{
            socket = new Socket("127.0.0.1", port);

            outputStream = new ObjectOutputStream(socket.getOutputStream());
            inputStream = new ObjectInputStream(socket.getInputStream());

            while(true){
                try{

                    Message message = (Message) inputStream.readObject();

                    client.inputInfo(message);

                    try {
                        client.notifyUpdate();
                    } catch (Exception i){

                    }
                    Message outgoingMessage = new Message(client);

                }catch(Exception error){
                    error.printStackTrace();
                }
            }

        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void sendMessage(){
        try{
            outputStream.writeObject(new Message(client));
            outputStream.reset();
        } catch (Exception i){

        }
    }

}
