package comp1206.sushi.common;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Map;

import comp1206.sushi.common.Postcode;

import javax.swing.*;

public class Postcode extends Model {

	private String name;
	private Map<String,Double> latLong;
	private Number distance;

	public Postcode(String code) {
		this.name = code;
		calculateLatLong();
		this.distance = Integer.valueOf(0);
	}
	
	public Postcode(String code, Restaurant restaurant) {
		this.name = code;
		calculateLatLong();
		calculateDistance(restaurant);
	}
	
	@Override
	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public Number getDistance() {
		return this.distance;
	}

	public Map<String,Double> getLatLong() {
		return this.latLong;
	}
	
	protected void calculateDistance(Restaurant restaurant) {
		//This function needs implementing

		Postcode destination = restaurant.getLocation();
		Map<String, Double> restaurantLatLon = destination.getLatLong();
		Map<String,Double> postcodeLatLon = this.latLong;

		int R = 6371000; // Earth's distance in m
		Double lat1 = restaurantLatLon.get("lat");
		Double lon1 = restaurantLatLon.get("lon");
		Double lat2 = postcodeLatLon.get("lat");
		Double lon2 = postcodeLatLon.get("lon");

		Double latDist = Math.toRadians(lat2-lat1);
		Double lonDist = Math.toRadians(lon2-lon1);
		lat1 = Math.toRadians(lat1);
		lat2 = Math.toRadians(lat2);

		double a = Math.pow(Math.sin(latDist / 2),2) + Math.pow(Math.sin(lonDist / 2),2) * Math.cos(lat1) * Math.cos(lat2);
		double c = 2 * Math.asin(Math.sqrt(a));
		double dist = R * c;

		this.distance = (int) Math.round(dist);

		/*Postcode destination = restaurant.getLocation();
		this.distance = Integer.valueOf(0);*/
	}
	
	protected void calculateLatLong() {
		//This function needs implementing

		try{
			String code = this.getName();
			code = code.replaceAll("\\s+","");
			URL myURL = new URL("https://www.southampton.ac.uk/~ob1a12/postcode/postcode.php?postcode=" + code);
			BufferedReader reader = new BufferedReader(new InputStreamReader(myURL.openStream()));
			String line = reader.readLine();

			int latFirst = (line.indexOf("\"lat\":\"")+7);
			int latLast = (line.indexOf("\",\"long"));

			int lonFirst = (line.indexOf("\"long\":\"")+8);
			int lonLast = (line.indexOf("\"}"));

			this.latLong = new HashMap<String,Double>();
			latLong.put("lat", Double.valueOf(line.substring(latFirst,latLast)));
			latLong.put("lon", Double.valueOf(line.substring(lonFirst,lonLast)));
			this.distance = new Integer(0);

		}catch(MalformedURLException error){
			JOptionPane.showMessageDialog(null, "There has been a malformed URL error", "Error", JOptionPane.ERROR_MESSAGE);

		}catch(UnknownHostException error){
			JOptionPane.showMessageDialog(null, "Please check your internet connection.", "Error", JOptionPane.ERROR_MESSAGE);

		}catch(IOException error){
			System.err.println(error);
		}

	}
	
}
