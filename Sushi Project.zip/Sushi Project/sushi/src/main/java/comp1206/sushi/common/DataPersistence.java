package comp1206.sushi.common;

public class DataPersistence {
}
