package comp1206.sushi.common;

import comp1206.sushi.server.Server;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class ServerComms {

    private static Server server;
    private static ServerSocket serverSocket;
    private ObjectInputStream inputStream;
    private ObjectOutputStream outputStream;
    private static int port = 5888;

    public ServerComms(Server server){
        this.server = server;
        try {
            serverSocket = new ServerSocket(port);
        } catch (IOException e){
            e.printStackTrace();
        }
        runServer();
    }

    private void runServer(){
        while(true){
            Socket socket = null;
            try {
                socket = serverSocket.accept();
                inputStream = new ObjectInputStream(socket.getInputStream());
                outputStream = new ObjectOutputStream(socket.getOutputStream());

                Runnable clientHandler = new ClientHandler(socket, inputStream, outputStream, server);

                Thread t = new Thread(clientHandler);

                t.start();

            } catch (IOException e){
                e.printStackTrace();
                try{
                    socket.close();
                }catch (IOException error){
                    error.printStackTrace();
                }
            }
        }

    }
}
