package comp1206.sushi.server;

import comp1206.sushi.common.Dish;
import comp1206.sushi.common.Ingredient;
import comp1206.sushi.server.ServerInterface;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class StockManagement {

    public Map<Ingredient,Number> ingredientStock = new HashMap<>();
    public Map<Dish,Number> dishStock = new HashMap<>();
    public Map<Ingredient,Number> tempIngredientStock = new HashMap<>();
    public Map<Dish,Number> tempDishStock = new HashMap<>();
    public ServerInterface server;

    public StockManagement(ServerInterface server){
        this.server = server;
    }

    public void addIngredient(Ingredient ingredient){
        ingredientStock.put(ingredient, Integer.valueOf(0));
        tempIngredientStock.put(ingredient, Integer.valueOf(0));
    }

    public void addDish(Dish dish){
        dishStock.put(dish, Integer.valueOf(0));
        tempDishStock.put(dish, Integer.valueOf(0));
    }

    public Map<Ingredient,Number> getIngredientStock(){
        return ingredientStock;
    }

    public Map<Dish,Number> getDishStock(){
        return dishStock;
    }

    public Ingredient getIngredientToRestock() throws InterruptedException{
        for(Map.Entry<Ingredient,Number> entry : tempIngredientStock.entrySet()){
            if(entry.getValue().intValue()<entry.getKey().getRestockThreshold().intValue()){
                stockIngredients(entry.getKey(), entry.getKey().getRestockAmount());
                return entry.getKey();
            }
        }

        return null;
    }

    public Dish getDishToRestock() throws InterruptedException{

        if(tempDishStock!=null) {
            for (Map.Entry<Dish, Number> entry : tempDishStock.entrySet()) {
                Map<Ingredient, Number> recipe = entry.getKey().getRecipe();
                List<Ingredient> recipeIngredients = new ArrayList<>();
                boolean enough = false;

                for (Ingredient key : recipe.keySet()) {
                    recipeIngredients.add(key);
                }

                if (entry.getValue().intValue() < entry.getKey().getRestockThreshold().intValue()) {
                    enough = enoughIngredients(recipe, recipeIngredients);
                }

                if (enough) {
                    for (Ingredient ingredient : recipeIngredients) {
                        ingredientStock.put(ingredient, ingredientStock.get(ingredient).intValue() - recipe.get(ingredient).intValue());
                        tempIngredientStock.put(ingredient, tempIngredientStock.get(ingredient).intValue() - recipe.get(ingredient).intValue());
                    }

                    tempDishStock.put(entry.getKey(), tempDishStock.get(entry.getKey()).intValue() + 1);

                    return entry.getKey();
                }
            }
        }

        return null;
    }

    public boolean enoughIngredients(Map<Ingredient,Number> recipe, List<Ingredient> recipeIngredients) throws InterruptedException{
        boolean enough = false;

        for (Ingredient ingredient : recipeIngredients) {
            if (recipe.get(ingredient).intValue() <= ingredientStock.get(ingredient).intValue()) {
                enough = true;
            } else {
                return false;
            }
        }

        if(enough){
            return true;
        }

        return false;

    }

    public synchronized void stockIngredients(Ingredient ingredient, Number restockAmount){
        tempIngredientStock.put(ingredient,tempIngredientStock.get(ingredient).intValue()+restockAmount.intValue());
    }

    public synchronized void updateIngredientStock(Ingredient ingredient){
        if(ingredientStock.isEmpty()==false) {
            ingredientStock.put(ingredient, ingredientStock.get(ingredient).intValue() + ingredient.getRestockAmount().intValue());
        }
    }

    public synchronized void updateDishStock(Dish dish){
        dishStock.put(dish, dishStock.get(dish).intValue()+1);
    }

    public void useDish(Dish dish){
        dishStock.replace(dish, dishStock.get(dish).intValue()-1);
        tempDishStock.replace(dish,tempDishStock.get(dish).intValue()-1);
    }


    public void clear(){
        dishStock.clear();
        tempDishStock.clear();
        ingredientStock.clear();
        tempIngredientStock.clear();
    }

}
