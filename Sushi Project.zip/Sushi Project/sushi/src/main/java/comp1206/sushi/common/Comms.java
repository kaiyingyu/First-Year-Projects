package comp1206.sushi.common;

import comp1206.sushi.client.Client;
import comp1206.sushi.server.Server;

public class Comms implements Runnable{
    private Client cc = null;
    private Server sc = null;
    private boolean created = false;

    public Comms(Client client){
        this.cc = client;
    }

    public Comms(Server server){
        this.sc = server;
    }

    public void sendMessage(String msg){

    }

    public void receiveMessage(String msg){

    }

    public void run(){
        if(created == false){
            if((this.cc == null) && (this.sc != null)){
                ServerComms serverComms = new ServerComms(sc);
                created = true;
            }
            else if((this.cc != null) && (this.sc == null)){
                ClientComms clientComms = new ClientComms(cc);
                created = true;
            }
        }
    }

}
