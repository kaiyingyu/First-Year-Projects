package comp1206.sushi.common;

import comp1206.sushi.server.Server;
import comp1206.sushi.server.ServerInterface;
import comp1206.sushi.server.StockManagement;

import java.util.*;

public class OrderManagement {

    public List<Order> tempOrders = new ArrayList<>();
    public Server server;
    private StockManagement stockManager;

    public OrderManagement(Server server, StockManagement stockManager){
        this.server = server;
        this.stockManager = stockManager;
    }

    public void addOrder(Order order){
        tempOrders.add(order);
    }

    public synchronized Order getOrderToDeliver(){
        if(tempOrders.size()!=0) {
            Iterator iterate = tempOrders.iterator();
            Order order = (Order) iterate.next();

            tempOrders.remove(order);

            return order;
        }

        return null;
    }

    public boolean fillOrder(Order order) {
        boolean filled = false;
        while (order.getStatus().equals("Pending")) {
            for (Map.Entry<Dish, Number> entry : order.getOrderContent().entrySet()) {
                Dish dishToOrder = getMatchingDish(entry.getKey().getName());

                if (entry.getValue().intValue()>0) {
                    if(stockManager.dishStock.get(dishToOrder).intValue()>0) {
                        stockManager.useDish(dishToOrder);
                        order.updateOrderContent(entry.getKey(), entry.getValue().intValue() - 1);
                    }
                }
            }

            int dishesLeft = 0;
            for (Map.Entry<Dish, Number> entry : order.getOrderContent().entrySet()) {
                dishesLeft = dishesLeft + entry.getValue().intValue();
            }

            if (dishesLeft == 0) {
                order.setStatus("Complete");
                filled = true;
                return filled;
            }
        }
        return filled;
    }

    public Dish getMatchingDish(String dishName){
        for(Dish dish:server.getDishes()){
            if(dishName.equals(dish.getName())){
                return dish;
            }
        }

        return null;
    }

    public void updateOrderList(Order removeOrder){
        server.orderCompleted(removeOrder);

        server.notifyUpdate();
    }
}
