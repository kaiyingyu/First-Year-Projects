package comp1206.sushi.common;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import comp1206.sushi.common.Order;

public class Order extends Model {

	private String status;
	private Map<Dish,Number> orderContent;
	private Number cost = 0;
	private Postcode postcode;
	private String orderID;
	private User user;
	
	public Order() {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/YYYY HH:mm:ss");  
		LocalDateTime now = LocalDateTime.now();  
		this.name = dtf.format(now);
	}

	public Order(User user, Map<Dish,Number> orderContent){
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/YYYY HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		this.name = dtf.format(now);
		this.orderContent = orderContent;

		setOrderUser(user);
		setPostcode(user.getPostcode());

		if(getOrderID()==null) {
			setOrderID(user.getName()+0);
		}

		setStatus("Pending");

        for (Map.Entry<Dish,Number> entry : orderContent.entrySet()) {
            cost = cost.floatValue() + (entry.getKey().getPrice().floatValue() * entry.getValue().intValue());
        }
	}

	public Postcode getPostcode() {
		return this.postcode;
	}

	public void setPostcode(Postcode postcode) {
		this.postcode = postcode;
	}

	public Number getDistance() {
		return postcode.getDistance();
	}

	@Override
	public String getName() {
		return this.name;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		notifyUpdate("status",this.status,status);
		this.status = status;
	}

	public Map<Dish,Number> getOrderContent(){
		return orderContent;
	}

	public void updateOrderContent(Dish dish, Number number){
		orderContent.replace(dish,number);
	}

    public Number getCost() {
        return cost;
    }

    public void setOrderID(String orderID){
		this.orderID = orderID;
	}

	public String getOrderID() {
		return orderID;
	}

	public void setOrderUser(User user){
		this.user = user;
		setPostcode(user.getPostcode());
	}

	public User getOrderUser(){
		return user;
	}

}
