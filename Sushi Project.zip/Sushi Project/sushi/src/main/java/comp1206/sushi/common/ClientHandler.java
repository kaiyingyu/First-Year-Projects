package comp1206.sushi.common;

import comp1206.sushi.server.Server;

import javax.print.DocFlavor;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;

public class ClientHandler implements Runnable{

    final Socket clientSocket;
    final ObjectInputStream inputStream;
    final  ObjectOutputStream outputStream;
    private Server server;


    ClientHandler(Socket clientSocket, ObjectInputStream inputStream, ObjectOutputStream outputStream, Server server){
        this.clientSocket = clientSocket;
        this.inputStream = inputStream;
        this.outputStream = outputStream;
        this.server = server;
        this.server.addHandler(this);
    }

    public void run(){
        sendMessage();
        while(true){
            try{
                Thread.sleep(1000);

                Message message = (Message) inputStream.readObject();

                addNewUsers(message);
                addClientOrders(message);

            }catch(Exception e){
                e.printStackTrace();
            }
        }

    }

    public void addNewUsers(Message message){
        boolean exists;

        for(User user:message.getUsers()){
            exists=false;
            for(User serverUser:server.getUsers()) {
                if(serverUser.getName().equals(user.getName())){
                    exists = true;
                    break;
                }
            }

            if(exists==false){
                for(Postcode code:server.getPostcodes()){
                    if(user.getPostcode().getName().equals(code.getName())){
                        user.setPostcode(code);
                    }
                }
                server.addUser(user.getName(), user.getPassword(), " dunno ", user.getPostcode());
            }
        }
    }

    public void addClientOrders(Message message){
        boolean exists;

        for(Order order:message.getOrders()){
            exists=false;
            for(Order serverOrder:server.getOrders()){
                if(order.getOrderID().equals(serverOrder.getOrderID())){
                    exists=true;
                    break;
                }
            }

            for(Order completeOrder:server.getCompletedOrders()){
                if(order.getOrderID().equals(completeOrder.getOrderID())){
                    exists=true;
                    break;
                }
            }

            if(exists==false){
                for(User user:server.getUsers()){
                    if(user.getName().equals(order.getOrderUser().getName())){
                        order.setOrderUser(user);
                    }
                }

                server.addOrder(order.getOrderUser(), order.getOrderContent());

                for(Order temp:server.getOrders()){
                    if(temp.getName().equals(order.getName())){
                        temp.setOrderID(order.getOrderID());
                    }
                }

            }
        }

    }

    public void sendMessage(){
        try{
            outputStream.writeObject(new Message(server));
            outputStream.reset();
        } catch (Exception i){

        }
    }

}
