import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertThrows;

import static org.junit.jupiter.api.Assertions.*;

class SPTTest {
    SPT spt;
    private int[][] graph = new int[5][5];

    @BeforeEach
    public void setUp(){
        spt = new SPT();

        for(int i=0;i<graph.length;i++){
            for(int j=0;j<graph[i].length;j++){
                graph[i][j] = -1;
            }
        }

    }

    @Test
    @DisplayName("Checks NullPointerException is thrown when edges are null")
    public void testNullEdgeGraph() {
        assertThrows(NullPointerException.class , () -> spt.findSPT(null, 1));
    }

    @Test
    @DisplayName("Testing input array is of equal dimensions")
    public void testEqualDimensions(){
        assertThrows(InvalidGraphException.class , () -> spt.findSPT(new int[2][3], 1));
    }

    @Test
    @DisplayName("Testing negative source")
    public void testNegativeSource(){
        assertThrows(InvalidSourceException.class , () -> spt.findSPT(graph, -5));
    }

    @Test
    @DisplayName("Testing source that is >= no. nodes")
    public void testBiggerSource(){
        assertThrows(InvalidSourceException.class , () -> spt.findSPT(graph,8));
    }

    @Test
    @DisplayName("Testing graph for loops")
    public void testLoops(){
        graph[2][2] = 1;
        assertThrows(LoopDetectedException.class , () -> spt.findSPT(graph, 1));
    }

    @Test
    @DisplayName("Testing for an unreachable node in a directed graph.")
    public void testDirectedUnreachableNode(){
        graph[0][1] = 1;
        graph[0][2] = 2;
        graph[0][3] = 3;
        graph[4][0] = 4;
        assertThrows(NoPathException.class , () -> spt.findSPT(graph, 0));
    }

    @Test
    @DisplayName("Testing for an unreachable node in an undirected graph.")
    public void testUndirectedUnreachableNode(){
        graph[0][1] = 3;
        graph[1][0] = 3;
        graph[0][2] = 3;
        graph[2][0] = 3;
        graph[1][3] = 5;
        graph[3][1] = 5;
        graph[2][3] = 2;
        graph[3][2] = 2;

        assertThrows(NoPathException.class , () -> spt.findSPT(graph, 0));
    }

    @Test
    @DisplayName("Checks input graph with no edges")
    public void testNoEdgeGraph(){
        assertThrows(NoPathException.class , () -> spt.findSPT(graph, 0));
    }

    @Test
    @DisplayName("Test if correct solution is returned for 5 node graph")
    public void testBasicSolution(){
        graph[0][1] = 3;
        graph[2][0] = 1;
        graph[1][2] = 8;
        graph[1][3] = 5;
        graph[2][3] = 3;
        graph[1][4] = 1;
        graph[3][4] = 7;

        int[] answer = {2,0,-1,2,1};

        try {
            assertArrayEquals(answer, spt.findSPT(graph, 2));
        }catch(Exception e){
            fail("Exception: " + e.toString() + " is thrown.");
        }
    }

    @Test
    @DisplayName("Test single node graph")
    public void testSingleNode(){
        int[][] node = new int[1][1];
        node[0][0] = -1;
        int[] answer = {-1};

        try {
            assertArrayEquals(answer, spt.findSPT(node, 0));
        }catch (Exception e){
            fail("Exception: " + e.toString() + " is thrown.");
        }
    }

    @Test
    @DisplayName("Test multiple SPTs")
    public void testMultipleSPT() {
        int match = 0;
        graph[0][1] = 3;
        graph[2][0] = 1;
        graph[1][2] = 8;
        graph[1][3] = 5;
        graph[2][3] = 3;
        graph[1][4] = 1;
        graph[3][4] = 3;

        try {
        int[] answer1 = {2, 0, -1, 2, 1};
        int[] answer2 = {2, 0, -1, 2, 3};

        if (Arrays.equals(spt.findSPT(graph, 2), answer1)) {
            match++;
        } else if (Arrays.equals(spt.findSPT(graph, 2), answer2)) {
            match++;
        }

        }catch(Exception e){
            fail("Exception: " + e.toString() + " is thrown.");
        }

        assertEquals(match,1);

    }

    @Test
    @DisplayName("Test SPT works for all nodes as well as the source")
    public void testAll(){
        graph[0][1] = 3;
        graph[1][0] = 3;
        graph[0][2] = 3;
        graph[2][0] = 3;
        graph[1][3] = 5;
        graph[3][1] = 5;
        graph[2][3] = 2;
        graph[3][2] = 2;
        graph[3][4] = 1;
        graph[4][3] = 1;

        try{
            assertArrayEquals(new int[]{-1,0,0,2,3}, spt.findSPT(graph,0));
            assertArrayEquals(new int[]{1,-1,0,1,3}, spt.findSPT(graph,1));
            assertArrayEquals(new int[]{2,0,-1,2,3}, spt.findSPT(graph,2));
            assertArrayEquals(new int[]{2,3,3,-1,3}, spt.findSPT(graph,3));
            assertArrayEquals(new int[]{2,3,3,4,-1}, spt.findSPT(graph,4));
        } catch (Exception e){
            fail("Exception: " + e.toString() + " is thrown.");
        }
    }

    @Test
    @DisplayName("Tests other negative edge values except for -1")
    public void testOtherNegatives(){
        graph[0][1] = 3;
        graph[1][0] = -5;
        graph[2][0] = 1;
        graph[0][2] = -9;
        graph[1][2] = 8;
        graph[2][1] = -87;
        graph[1][3] = 5;
        graph[3][1] = -1000;
        graph[2][3] = 3;
        graph[3][2] = -532;
        graph[1][4] = 1;
        graph[3][4] = 7;

        int[] answer = {2,0,-1,2,1};

        try {
            assertArrayEquals(answer, spt.findSPT(graph, 2));
        }catch(Exception e){
            fail("Exception: " + e.toString() + " is thrown.");
        }
    }

    @Test
    @DisplayName("Tests weight 0 is represented correctly")
    public void zeroWeightTest(){
        int[][] testGraph = new int[3][3];

        for(int i=0;i<testGraph.length;i++){
            for(int j=0;j<testGraph[i].length;j++){
                testGraph[i][j] = -1;
            }
        }

        testGraph[0][1] = 0;
        testGraph[0][2] = 2;
        testGraph[1][2] = 1;

        int[] answer = {-1, 0, 1};

        try {
            assertArrayEquals(answer, spt.findSPT(testGraph, 0));
        } catch(Exception e){
        fail("Exception: " + e.toString() + " is thrown.");
        }
    }

    @Test
    @DisplayName("Test harder example")
    public void testComplexGraph(){
        int[][] testGraph = new int [15][15];

        for(int i=0;i<testGraph.length;i++){
            for(int j=0;j<testGraph[i].length;j++){
                testGraph[i][j] = -1;
            }
        }

        testGraph[0][1] = 1;
        testGraph[0][2] = 6;
        testGraph[1][2] = 1;
        testGraph[1][3] = 2;
        testGraph[2][3] = 8;
        testGraph[3][4] = 6;
        testGraph[4][5] = 5;
        testGraph[5][6] = 3;
        testGraph[5][7] = 12;
        testGraph[6][7] = 7;
        testGraph[6][10] = 18;
        testGraph[7][8] = 3;
        testGraph[8][9] = 2;
        testGraph[9][10] = 5;
        testGraph[10][11] = 4;
        testGraph[11][12] = 7;
        testGraph[12][13] = 3;
        testGraph[13][14] = 9;

        int[] answer = {-1, 0, 1, 1, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13};

        try{
        assertArrayEquals(answer, spt.findSPT(testGraph, 0));
        } catch(Exception e){
            fail("Exception: " + e.toString() + " is thrown.");
        }
    }

    @AfterEach
    public void tearDown(){
    }
}